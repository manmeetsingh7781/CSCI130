const function_expression = document.getElementById("fun_expression")
let a3 = "a<sub>3</sub>", a2 = "a<sub>2</sub>", a1 = "a<sub>1</sub>", a0 = "a<sub>0</sub>", n = 0, xmin = 0, xmax = 0;

const canvas = document.getElementById("canvas")
const ctx = canvas.getContext("2d")

function updateExpression() {
    function_expression.innerHTML = `${a3}x<sup>3</sup> + 
    ${a2}x<sup>2</sup>+
    ${a1}x +
    ${a0}`   
}

function submitForm() {
  
    a3 = parseFloat(document.getElementById("a3").value);
    a2 = parseFloat(document.getElementById("a2").value);
    a1 = parseFloat(document.getElementById("a1").value);
    a0 = parseFloat(document.getElementById("a0").value);
    xmin = parseFloat(document.getElementById("xmin").value);
    xmax = parseFloat(document.getElementById("xmax").value);
    n = parseFloat(document.getElementById("n").value);

    updateExpression()

    const values = {
        "a3" :  a3,
        "a2" :  a2,
        "a1" :  a1,
        "a0" :  a0,
        "xmin" :  xmin,
        "xmax" :  xmax,
        "n" :  n
    }

    ctx.fillStyle = "black"
    ctx.fillRect(0, 0, 600, 600)

    // xmin xmax defines the axis length
    console.log(values)
    const step = (values['xmax'] - values['xmin']) / values['n']
    console.log("step " , step)
    for (let x = values["xmin"]; x < values['xmax']; x+=step) {
        const fx = (values["a3"] * Math.pow(x, 3)) + (values["a2"] * Math.pow(x, 2)) + (values["a1"] * x) + values["a0"] 
        console.log(`f(${x}) = `, fx)
        ctx.beginPath();

        ctx.arc(x, fx, 5, 0, Math.PI * 2);
        ctx.fillStyle = "red"
        ctx.fill();
    }

   


}

